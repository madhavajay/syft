from syftbox import lib


def test_import():
    dir(lib)
